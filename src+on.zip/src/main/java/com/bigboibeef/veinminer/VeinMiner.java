package com.bigboibeef.veinminer;

import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.VaultBlockEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Set;

public class VeinMiner implements ModInitializer {
	public static final String MOD_ID = "veinminer";

	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	public static final TagKey<Block> ores = TagKey.of(Registries.BLOCK.getKey(), Identifier.of("veinminer", "ores"));

	@Override
	public void onInitialize() {
			PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
				int max = 0;
				BlockPos[] OFFSETS = new BlockPos[] {
						new BlockPos(1, 0, 0),
						new BlockPos(-1, 0, 0),
						new BlockPos(0, 1, 0),
						new BlockPos(0, -1, 0),
						new BlockPos(0, 0, 1),
						new BlockPos(0, 0, -1)
				};

				Set<BlockPos> vein = new HashSet<>();
				Set<BlockPos> frontier = new HashSet<>();

				vein.add(pos);
				frontier.add(pos);

				while (!frontier.isEmpty() && max <= 20) {
					LOGGER.info("while " + vein.size() + ", " + pos);
					if (vein.size() >= 100) break;
					Set<BlockPos> nextFrontier = new HashSet<>();

					for (BlockPos current : frontier) {
						for (BlockPos offset : OFFSETS) {
							BlockPos neighbor = current.add(offset);

							if (vein.contains(neighbor)) continue;

							BlockState newState = world.getBlockState(neighbor);
							if (isOre(newState)) {
								vein.add(neighbor);
								nextFrontier.add(neighbor);
							}
						}
					}

					frontier = nextFrontier;
					max++;
				}
				vein.forEach(ore -> {
					world.breakBlock(ore, true, player);
				});
			});
	}

	public boolean isOre (BlockState state) {
		boolean result = state.isIn(ores);
		if (!result) {
			LOGGER.info("Skipped block: {}", state.getBlock().getName().getString() + ", " + state);
		}
        return result;
    }
}

/*
* get all blocks around
* if ore save in set
* if set empty return
* if set contains for each check if ore recursive
* */